ALTER TABLE `sticker_packs` ADD `style` varchar(50) DEFAULT 'cute_cartoon' NOT NULL;--> statement-breakpoint
ALTER TABLE `sticker_packs` ADD `bodyType` varchar(50) DEFAULT 'half_body' NOT NULL;