import archiver from "archiver";
import { Readable } from "stream";

export interface StickerFile {
  filename: string;
  url: string;
}

/**
 * Create a ZIP file containing stickers and instructions
 */
export async function createStickerZip(
  packName: string,
  stickers: StickerFile[]
): Promise<Buffer> {
  return new Promise(async (resolve, reject) => {
    const archive = archiver("zip", {
      zlib: { level: 9 }, // Maximum compression
    });

    const chunks: Buffer[] = [];

    archive.on("data", (chunk) => {
      chunks.push(chunk);
    });

    archive.on("end", () => {
      const buffer = Buffer.concat(chunks);
      resolve(buffer);
    });

    archive.on("error", (err) => {
      reject(err);
    });

    // Download and add each sticker to the ZIP
    for (const sticker of stickers) {
      try {
        const response = await fetch(sticker.url);
        if (!response.ok) {
          console.warn(`Failed to download sticker: ${sticker.filename}`);
          continue;
        }

        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        archive.append(buffer, { name: sticker.filename });
      } catch (error) {
        console.error(`Error downloading sticker ${sticker.filename}:`, error);
      }
    }

    // Add README with instructions
    const readme = createReadmeContent(packName);
    archive.append(readme, { name: "README.txt" });

    // Finalize the archive
    await archive.finalize();
  });
}

function createReadmeContent(packName: string): string {
  return `คู่มือการอัปโหลดสติกเกอร์ไปยัง Telegram
========================================================

🎉 ชุดสติกเกอร์: ${packName}

ขั้นตอนการอัปโหลดสติกเกอร์ไป Telegram
========================================================

ขั้นที่ 1: เปิด @Stickers Bot
   1. เปิดแอป Telegram บนมือถือของคุณ
   2. คลิกที่ไอคอนกระทู้ (🔍) แล้วค้นหา "@Stickers"
   3. คลิกที่ @Stickers bot แล้วกด "Start" หรือ "เริ่มต้น"

ขั้นที่ 2: สร้างชุดสติกเกอร์ใหม่
   1. พิมพ์คำสั่ง: /newpack
   2. Bot จะถามชื่อชุดสติกเกอร์ - พิมพ์ชื่อที่คุณต้องการ
      ตัวอย่าง: "สติกเกอร์ของฉัน" หรือ "My Stickers"

ขั้นที่ 3: อัปโหลดสติกเกอร์
   1. คลิกที่ไอคอนคลิป (📎) ใน Telegram
   2. เลือกไฟล์สติกเกอร์ .png จากโฟลเดอร์นี้
   3. ส่งไฟล์ทีละรูปไปให้ Bot
   4. Bot จะถามให้เลือก Emoji - พิมพ์ emoji ที่เหมาะสม
      ตัวอย่าง: 😊 สำหรับสติกเกอร์ยิ้ม, 😢 สำหรับสติกเกอร์เศร้า
   5. ทำซ้ำสำหรับสติกเกอร์ทุกรูป

ขั้นที่ 4: เผยแพร่ชุดสติกเกอร์
   1. หลังอัปโหลดสติกเกอร์ครบแล้ว พิมพ์คำสั่ง: /publish
   2. Bot จะขอให้ส่งไอคอน - ส่งรูปสติกเกอร์รูปหนึ่งเป็นไอคอน
   3. Bot จะถามชื่อสั้น (Short name) - พิมพ์ชื่อสั้นภาษาอังกฤษ
      ตัวอย่าง: "mystickers" หรือ "my_cool_stickers"
   4. เสร็จ! คุณจะได้รับลิงก์สติกเกอร์ของคุณ 🎉

ข้อกำหนดสติกเกอร์ Telegram
========================================================
✅ ขนาด: 512 x 512 pixels
✅ รูปแบบ: PNG พร้อมพื้นหลังโปร่งใส
✅ ขนาดไฟล์: ไม่เกิน 512 KB

สติกเกอร์ทั้งหมดในโฟลเดอร์นี้ตรงตามข้อกำหนดแล้ว

คำสั่งที่มีประโยชน์
========================================================
/addsticker - เพิ่มสติกเกอร์ในชุดที่มีอยู่
/delsticker - ลบสติกเกอร์ออกจากชุด
/stats - ดูสถิติการใช้งานสติกเกอร์
/cancel - ยกเลิกการทำงานปัจจุบัน

สนุกกับการสร้างสติกเกอร์! 🎉🎈
`;
}
